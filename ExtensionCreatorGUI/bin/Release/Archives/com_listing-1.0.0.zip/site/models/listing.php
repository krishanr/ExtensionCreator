<?php
/**
 * Listing Model for Listing Component
 * 
 * @package    Listing
 * @subpackage com_listing
 * @license  GNU General Public License version 2 or later
 *
 */

// No direct access
defined('_JEXEC') or die( 'Restricted access' );

/**
 * Listing Model
 *
 * @package    Joomla.Components
 * @subpackage 	Listing
 */
class ListingModelListing extends JModelLegacy {

}
