<?php
/**
 * com_listing default controller
 * 
 * @package    Listing
 * @subpackage com_listing
 * @license  GNU General Public License version 2 or later
 *
 */

// No direct access
defined('_JEXEC') or die( 'Restricted access' );

/**
 * listing Component Controller
 *
 * @package	Listing
 */
class ListingController extends JControllerLegacy
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

}
?>
